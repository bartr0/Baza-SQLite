package com.example.myasynctask;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.concurrent.ThreadLocalRandom;

public class MainActivity extends AppCompatActivity {

    RadioButton r1;
    RadioButton r2;
    RadioButton r3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        r1.findViewById(R.id.R1);
//        r2.findViewById(R.id.R2);
//        r3.findViewById(R.id.R3);
//
//        r1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v){
//                r1.setBackgroundColor(Color.rgb( 0, 0, 255));
//            }
//        });
        LinearLayout widok = findViewById(R.id.view);
        Button button = (Button) findViewById(R.id.R1);
        button.setOnClickListener((new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                widok.setBackgroundColor(Color.rgb(66, 135, 245));
            }

        }));
        Button button2 = (Button) findViewById(R.id.R2);
        button2.setOnClickListener((new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                widok.setBackgroundColor(Color.rgb(245, 66, 90));
            }

        }));
        Button button3 = (Button) findViewById(R.id.R3);
        button3.setOnClickListener((new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                widok.setBackgroundColor(Color.rgb(73, 209, 130));
            }

        }));
    }
}